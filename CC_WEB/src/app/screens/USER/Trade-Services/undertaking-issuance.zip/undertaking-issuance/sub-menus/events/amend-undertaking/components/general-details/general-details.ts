import { Component } from '@angular/core';

import { MatButtonModule } from '@angular/material/button';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatIcon } from "@angular/material/icon";
@Component({
  selector: 'app-general-details',
  standalone: true,
  imports: [
    MatButtonModule,
    MatRadioModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    MatSlideToggleModule,
    MatIcon
],
  templateUrl: './general-details.html',
  styleUrl: './general-details.scss',
})
export class GeneralDetails {
  isOpen = true;
  currentStep = 0;
  steps = [
    { label: "General Details" },
    { label: "Shipment Details" },
    { label: "Documents Upload" }
  ];

  toggle() {
    this.isOpen = !this.isOpen;
  }


  selectStep(i: number) { this.currentStep = i; }
  next() { if (this.currentStep < this.steps.length - 1) this.currentStep++; }

}


