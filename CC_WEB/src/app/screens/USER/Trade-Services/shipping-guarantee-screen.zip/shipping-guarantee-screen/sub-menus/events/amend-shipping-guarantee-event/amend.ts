import { Component, OnInit } from '@angular/core';

import {
  FormArray,
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';

import {
  Router,
  RouterOutlet,
  ActivatedRoute
} from '@angular/router';

import { CommonModule } from '@angular/common';

import { MatSnackBar } from '@angular/material/snack-bar';

import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { finalize } from 'rxjs';

import { ApiService } from '../../../../../../../core/services/api.service';

import { ShippingGuaranteeTransaction } from '../../../../../../../core/models/shipping-guarantee';

import { Sidebar } from '../../../../../../../core/sidebar/sidebar';

import { RejectDialogComponent } from '../../../../../../../shared/reject-dialog/reject-dialog';

import { ApplicantBeneficiary } from '../../../../shipping-guarantee-screen/sub-menus/events/amend-shipping-guarantee-event/components/applicant-beneficiary/applicant-beneficiary';

import { GeneralDetails } from '../../../../shipping-guarantee-screen/sub-menus/events/amend-shipping-guarantee-event/components/general-details/general-details';

import { InstructionToBank } from '../../../../shipping-guarantee-screen/sub-menus/events/amend-shipping-guarantee-event/components/instruction-to-bank/instruction-to-bank';

import { BankDetails } from '../../../../shipping-guarantee-screen/sub-menus/events/amend-shipping-guarantee-event/components/bank-details/bank-details';

import { Attachments } from '../../../../shipping-guarantee-screen/sub-menus/events/amend-shipping-guarantee-event/components/attachments/attachments';


@Component({
  selector: 'app-amend',

  standalone: true,

  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatDialogModule,
    RouterOutlet,
    Sidebar,
    GeneralDetails,
    ApplicantBeneficiary,
    BankDetails,
    InstructionToBank,
    Attachments
  ],

  templateUrl: './amend.html',

  styleUrls: ['./amend.scss']
})
export class Amend implements OnInit {


  // =========================================================
  // FORM / SCREEN STATE
  // =========================================================

  currentStep = 0;

  ShippingGuaranteeForm!: FormGroup;

  mode: 'CREATE' | 'UPDATE' | 'REJECTED' = 'CREATE';

  screenMode:
    | 'EDIT'
    | 'SUBMITTED'
    | 'APPROVED'
    | 'FINAL' = 'EDIT';

  currentTx: ShippingGuaranteeTransaction =
    {} as ShippingGuaranteeTransaction;


  showUpdateSubmit = false;

  showApproveReject = false;

  rejectionReason = '';

  tnxId = '';

  companyId = '';

  eventType = '';

  eventRefNo = '';

  requestedMode = '';

  sourceTab = '';

  isSaving = false;

  isHistoricalView = false;


  // =========================================================
  // PERMISSIONS
  // =========================================================

  permissionNames: string[] = [];


  hasPermission(permission: string): boolean {

    return this.permissionNames.some(
      p =>
        p.trim().toLowerCase() ===
        permission.toLowerCase()
    );

  }


  // =========================================================
  // SIDEBAR STEPS
  // =========================================================

  shippingGuaranteeSteps = [
    { label: 'General Details' },
    { label: 'Applicant & Beneficiary' },
    { label: 'Bank Details' },
    { label: 'Instructions' },
    { label: 'Attachments' }
  ];


  // =========================================================
  // CONSTRUCTOR
  // =========================================================

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private snackBar: MatSnackBar,
    private api: ApiService,
    private route: ActivatedRoute,
    private dialog: MatDialog
  ) {

    this.buildForm();

  }


  // =========================================================
  // ON INIT
  // =========================================================

  ngOnInit(): void {


    // =======================================================
    // LOAD PERMISSIONS
    // =======================================================

    const storedPermissions =
      sessionStorage.getItem('permissionNames');

    if (storedPermissions) {

      try {

        this.permissionNames =
          JSON.parse(storedPermissions);

      } catch {

        this.permissionNames = [];

      }

    }

    console.log(
      'Shipping Guarantee Amend Permissions:',
      this.permissionNames
    );


    // =======================================================
    // INTERSECTION OBSERVER
    // =======================================================

    setTimeout(() => {

      const sections =
        document.querySelectorAll('section');

      const observer =
        new IntersectionObserver(

          entries => {

            entries.forEach(entry => {

              if (entry.isIntersecting) {

                this.currentStep =
                  Array.from(sections).indexOf(
                    entry.target as HTMLElement
                  );

              }

            });

          },

          {
            threshold: 0.4,
            root:
              document.querySelector('.scroll-area')
          }

        );

      sections.forEach(section =>
        observer.observe(section)
      );

    }, 200);


    // =======================================================
    // COMPANY ID
    // =======================================================

    const sessionData =
      JSON.parse(
        sessionStorage.getItem('userData') || '{}'
      );

    this.companyId =
      sessionData.companyId ?? '';


    console.log(
      'Company ID:',
      this.companyId
    );


    // =======================================================
    // ROUTE
    // =======================================================

    this.route.paramMap.subscribe(params => {

      this.tnxId =
        params.get('tnxId') || '';

      this.route.queryParamMap.subscribe(q => {

        this.requestedMode =
          q.get('mode') ?? '';

        this.sourceTab =
          q.get('tab') ?? '';

        this.eventType =
          q.get('eventType') ?? '';

        this.eventRefNo =
          q.get('eventRefNo') ?? '';


        console.log(
          'tnxId:',
          this.tnxId
        );

        console.log(
          'sourceTab:',
          this.sourceTab
        );

        console.log(
          'eventType:',
          this.eventType
        );

        console.log(
          'eventRefNo:',
          this.eventRefNo
        );


        if (this.tnxId) {

          this.enterEditMode(
            this.tnxId
          );

        } else {

          this.enterCreateMode();

        }

      });

    });

  }


  // =========================================================
  // BUILD FORM
  // =========================================================

  private buildForm(): void {

    this.ShippingGuaranteeForm =
      this.fb.group({

        generalDetailsForm:
          this.fb.group({

            expiryDate: [''],

            beneficiaryReference: [''],

            customerReference: [''],

            billoflading: [''],

            modeOfShipment: [''],

            shippingDetails: [''],

            description: ['']

          }),


        applicantBeneficiaryForm:
          this.fb.group({

            applicantName: [''],

            applicantAddress1: [''],

            applicantAddress2: [''],

            applicantAddress3: [''],

            applicantAddress4: [''],

            applicantCountry: [''],

            beneficiaryName: [''],

            beneficiaryAddress1: [''],

            beneficiaryAddress2: [''],

            beneficiaryAddress3: [''],

            beneficiaryAddress4: [''],

            beneficiaryCountry: ['']

          }),


        issuingbankForm:
          this.fb.group({

            bankName: [''],

            issuerReference: [''],

            currency: [''],

            amount: ['']

          }),


        instructionForm:
          this.fb.group({

            principalAccount: [''],

            feeAccount: [''],

            otherInstructions: ['']

          }),


        attachments:
          this.fb.array([])

      });

  }


  // =========================================================
  // CREATE MODE
  // =========================================================

  private enterCreateMode(): void {

    this.mode = 'CREATE';

    this.showUpdateSubmit = false;

    this.showApproveReject = false;

    this.isHistoricalView = false;

    this.currentTx =
      {} as ShippingGuaranteeTransaction;

    this.ShippingGuaranteeForm.reset();

    this.buildForm();

  }


  // =========================================================
  // EDIT MODE
  // =========================================================

  private enterEditMode(
    tnxId: string
  ): void {

    this.mode = 'UPDATE';


    // =======================================================
    // SCENARIO 1
    // HISTORICAL EVENT
    // =======================================================

    if (this.eventRefNo) {

      this.isHistoricalView = true;

      this.api
        .getAmendmentByEventRefNoSg(
          this.eventRefNo
        )
        .subscribe({

          next: event => {

            this.currentTx = event;

            this.screenMode =
              'APPROVED';

            this.ShippingGuaranteeForm.disable();

            this.patchForm(event);

          },

          error: () => {

            this.snackBar.open(
              'Event snapshot not found',
              'Close',
              {
                duration: 3000
              }
            );

            this.router.navigate([
              '/dashboard/Trade-Services/shipping-guarantee/inquiries-records'
            ]);

          }

        });

      return;

    }


    // =======================================================
    // SCENARIO 2
    // LIVE TAB
    // =======================================================

    if (this.sourceTab === 'live') {

      this.isHistoricalView = false;

      this.api
        .getAmendmentByTnxIdSg(tnxId)
        .subscribe({

          next: event => {

            this.currentTx = event;

            this.patchForm(event);


            if (event.status === 'I') {

              this.screenMode =
                'EDIT';

              this.ShippingGuaranteeForm.enable();

            } else {

              this.screenMode =
                'SUBMITTED';

              this.ShippingGuaranteeForm.disable();

            }

          },

          error: () => {

            this.api
              .getTransactionSgByTnxId(tnxId)
              .subscribe({

                next: tx => {

                  this.currentTx = {
                    tnxId: tx.tnxId
                  } as ShippingGuaranteeTransaction;

                  this.patchForm(tx);

                  this.screenMode =
                    'EDIT';

                  this.ShippingGuaranteeForm.enable();

                },

                error: () => {

                  this.snackBar.open(
                    'Transaction not found',
                    'Close',
                    {
                      duration: 3000
                    }
                  );

                  this.router.navigate([
                    '/dashboard/Trade-Services/shipping-guarantee/inquiries-records'
                  ]);

                }

              });

          }

        });

      return;

    }


    // =======================================================
    // SCENARIO 3
    // AMENDMENT TABS
    // =======================================================

    const isAmendmentTab =
      this.eventType === 'AMD' ||
      this.sourceTab === 'pending' ||
      this.sourceTab === 'submitted' ||
      this.sourceTab === 'approved' ||
      this.sourceTab === 'rejected';


    if (isAmendmentTab) {

      this.isHistoricalView = false;

      this.api
        .getAmendmentByTnxIdSg(tnxId)
        .subscribe({

          next: event => {

            this.currentTx = event;

            this.patchForm(event);


            switch (event.status) {

              case 'I':

                this.mode =
                  'UPDATE';

                this.screenMode =
                  'EDIT';

                this.ShippingGuaranteeForm.enable();

                break;


              case 'S':

                this.mode =
                  'UPDATE';

                this.screenMode =
                  'SUBMITTED';

                this.ShippingGuaranteeForm.disable();

                break;


              case 'A':

                this.mode =
                  'UPDATE';

                this.screenMode =
                  'APPROVED';

                this.ShippingGuaranteeForm.disable();

                break;


              case 'R':

                this.mode =
                  'REJECTED';

                this.screenMode =
                  'EDIT';

                this.ShippingGuaranteeForm.enable();

                break;


              default:

                this.mode =
                  'UPDATE';

                this.screenMode =
                  'FINAL';

                this.ShippingGuaranteeForm.disable();

            }

          },

          error: () => {

            this.snackBar.open(
              'Amendment not found',
              'Close',
              {
                duration: 3000
              }
            );

            this.router.navigate([
              '/dashboard/Trade-Services/shipping-guarantee/inquiries-records'
            ]);

          }

        });

      return;

    }


    // =======================================================
    // SCENARIO 4
    // MASTER TRANSACTION
    // =======================================================

    this.isHistoricalView = false;

    this.api
      .getTransactionSgByTnxId(tnxId)
      .subscribe({

        next: tx => {

          this.currentTx = tx;

          this.patchForm(tx);


          switch (tx.status) {

            case 'I':

              this.mode =
                'UPDATE';

              this.screenMode =
                'EDIT';

              this.ShippingGuaranteeForm.enable();

              break;


            case 'S':

              this.mode =
                'UPDATE';

              this.screenMode =
                'SUBMITTED';

              this.ShippingGuaranteeForm.disable();

              break;


            case 'A':

              this.mode =
                'UPDATE';

              if (
                this.requestedMode === 'EDIT'
              ) {

                this.screenMode =
                  'EDIT';

                this.ShippingGuaranteeForm.enable();

              } else {

                this.screenMode =
                  'APPROVED';

                this.ShippingGuaranteeForm.disable();

              }

              break;


            case 'R':

              this.mode =
                'REJECTED';

              this.screenMode =
                'EDIT';

              this.ShippingGuaranteeForm.enable();

              break;


            default:

              this.mode =
                'UPDATE';

              this.screenMode =
                'FINAL';

              this.ShippingGuaranteeForm.disable();

          }

        },

        error: () => {

          this.snackBar.open(
            'Transaction not found',
            'Close',
            {
              duration: 3000
            }
          );

          this.router.navigate([
            '/dashboard/Trade-Services/shipping-guarantee/inquiries-records'
          ]);

        }

      });

  }


  // =========================================================
  // FORM GETTERS
  // =========================================================

  get generalDetailsForm(): FormGroup {

    return this.ShippingGuaranteeForm.get(
      'generalDetailsForm'
    ) as FormGroup;

  }


  get applicantBeneficiaryForm(): FormGroup {

    return this.ShippingGuaranteeForm.get(
      'applicantBeneficiaryForm'
    ) as FormGroup;

  }


  get issuingbankForm(): FormGroup {

    return this.ShippingGuaranteeForm.get(
      'issuingbankForm'
    ) as FormGroup;

  }


  get instructionForm(): FormGroup {

    return this.ShippingGuaranteeForm.get(
      'instructionForm'
    ) as FormGroup;

  }


  get attachmentsArray(): FormArray {

    return this.ShippingGuaranteeForm.get(
      'attachments'
    ) as FormArray;

  }


  // =========================================================
  // PATCH FORM
  // =========================================================

  private patchForm(
    tx: ShippingGuaranteeTransaction
  ): void {

    this.ShippingGuaranteeForm.patchValue({

      generalDetailsForm: tx,

      applicantBeneficiaryForm: tx,

      issuingbankForm: tx,

      instructionForm: tx

    });

  }


  // =========================================================
  // SCROLL
  // =========================================================

  scrollToSection(
    index: number
  ): void {

    this.currentStep = index;

    document
      .getElementById(`section-${index}`)
      ?.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });

  }


  // =========================================================
  // FLATTEN FORM
  // =========================================================

  private flattenForm():
    ShippingGuaranteeTransaction {

    return {

      companyId: this.companyId,

      ...this.ShippingGuaranteeForm.value
        .generalDetailsForm,

      ...this.ShippingGuaranteeForm.value
        .applicantBeneficiaryForm,

      ...this.ShippingGuaranteeForm.value
        .issuingbankForm,

      ...this.ShippingGuaranteeForm.value
        .instructionForm,

      attachments:
        this.ShippingGuaranteeForm.value
          .attachments

    };

  }


  // =========================================================
  // SAVE AMENDMENT
  // =========================================================

  saveForm(): void {

    if (!this.hasPermission('SG_AmendSave')) {
      return;
    }


    if (this.isSaving) {
      return;
    }

    this.isSaving = true;


    if (!this.companyId) {

      this.snackBar.open(
        'Session expired or company not found.',
        'Close',
        {
          duration: 3000
        }
      );

      this.isSaving = false;

      return;

    }


    const payload =
      this.flattenForm();

    console.log(
      'Payload before saving draft:',
      payload
    );


    const tnxId =
      this.currentTx?.tnxId;


    if (!tnxId) {

      this.snackBar.open(
        'Transaction ID missing. Cannot amend.',
        'Close',
        {
          duration: 3000
        }
      );

      this.isSaving = false;

      return;

    }


    this.api
      .saveAmendTransactionSg(
        tnxId,
        payload
      )
      .pipe(
        finalize(
          () =>
            this.isSaving = false
        )
      )
      .subscribe({

        next:
          (
            res: ShippingGuaranteeTransaction
          ) => {

            this.currentTx = {
              ...this.currentTx,
              ...res
            };


            console.log(
              'Saved amendment, eventRefNo:',
              this.currentTx.eventRefNo
            );


            this.snackBar.open(
              `Amendment saved (Ref: ${
                res.eventRefNo ??
                res.tnxId
              })`,
              'Close',
              {
                duration: 5000
              }
            );


            setTimeout(() => {

              this.router.navigate(
                [
                  '/dashboard/Trade-Services/shipping-guarantee/approved-inquiry-records'
                ],
                {
                  queryParams: {
                    tab: 'pending'
                  }
                }
              );

            }, 50);

          },

        error: () => {

          this.snackBar.open(
            'Error saving amendment',
            'Close',
            {
              duration: 3000
            }
          );

        }

      });

  }


  // =========================================================
  // SUBMIT AMENDMENT
  // =========================================================

  submitLc(): void {

    if (!this.hasPermission('SG_AmendSubmit')) {
      return;
    }


    const eventRefNo =
      this.currentTx?.eventRefNo;


    console.log(
      'Submitting amendment, eventRefNo:',
      eventRefNo
    );


    if (!eventRefNo) {

      this.snackBar.open(
        'Please save the amendment draft first.',
        'Close',
        {
          duration: 3000
        }
      );

      return;

    }


    const payload = {

      ...this.flattenForm(),

      event: 'AMD',

      tnxId: this.tnxId

    };


    this.api
      .submitAmendmentSg(
        eventRefNo,
        payload
      )
      .subscribe({

        next: res => {

          this.router.navigate(
            [
              '/dashboard/Trade-Services/shipping-guarantee/success'
            ],
            {
              state: {
                source: 'SHIPPING_GUARANTEE_AMD',
                transaction: res
              }
            }
          );


          this.snackBar.open(
            `Amendment Submitted (Ref: ${
              res.eventRefNo ??
              res.tnxId
            })`,
            'Close',
            {
              duration: 5000
            }
          );


          setTimeout(() => {

            this.router.navigate([
              '/dashboard/Trade-Services/shipping-guarantee/approved-inquiry-records'
            ]);

          }, 50);

        },

        error: () => {

          this.snackBar.open(
            'Error submitting amendment',
            'Close',
            {
              duration: 3000
            }
          );

        }

      });

  }


  // =========================================================
  // APPROVE
  // =========================================================

  approve(): void {

    if (!this.hasPermission('SG_AmendApprove')) {
      return;
    }


    const eventRefNo =
      this.currentTx?.eventRefNo;


    if (!eventRefNo) {

      this.snackBar.open(
        'Amendment reference not found.',
        'Close',
        {
          duration: 3000
        }
      );

      return;

    }


    const payload = {

      ...this.flattenForm(),

      event: 'AMD',

      tnxId: this.tnxId

    };


    this.api
      .approveAmendmentSg(
        eventRefNo,
        payload
      )
      .subscribe({

        next: () => {

          this.snackBar.open(
            'Amendment approved. Live Shipping Guarantee updated.',
            'Close',
            {
              duration: 3000
            }
          );


          setTimeout(() => {

            this.router.navigate([
              '/dashboard/Trade-Services/shipping-guarantee/inquiries-records'
            ]);

          }, 50);

        },

        error: () => {

          this.snackBar.open(
            'Approval failed',
            'Close',
            {
              duration: 3000
            }
          );

        }

      });

  }


  // =========================================================
  // REJECT
  // =========================================================

  openReject(): void {

    if (!this.hasPermission(
      'SG_AmendReject'
    )) {
      return;
    }


    const eventRefNo =
      this.currentTx?.eventRefNo;


    if (!eventRefNo) {

      this.snackBar.open(
        'Amendment reference not found.',
        'Close',
        {
          duration: 3000
        }
      );

      return;

    }


    const dialogRef =
      this.dialog.open(
        RejectDialogComponent,
        {
          width: '400px'
        }
      );


    dialogRef
      .afterClosed()
      .subscribe(
        (
          reason: string | undefined
        ) => {

          if (!reason) {
            return;
          }


          this.api
            .rejectAmendmentSg(
              eventRefNo,
              reason
            )
            .subscribe({

              next: () => {

                this.snackBar.open(
                  'Amendment rejected. Live Shipping Guarantee unchanged.',
                  'Close',
                  {
                    duration: 3000
                  }
                );


                this.navigateBack(
                  'rejected'
                );

              },

              error: () => {

                this.snackBar.open(
                  'Failed to reject amendment',
                  'Close',
                  {
                    duration: 3000
                  }
                );

              }

            });

        }
      );

  }


  // =========================================================
  // UPDATE REJECTED
  // =========================================================

  updateRejected(): void {

    if (!this.hasPermission(
      'SG_AmendUpdateReject'
    )) {
      return;
    }


    if (
      this.ShippingGuaranteeForm.invalid ||
      !this.currentTx?.tnxId
    ) {

      this.snackBar.open(
        'Invalid form or missing transaction ID',
        'Close',
        {
          duration: 3000
        }
      );

      return;

    }


    const payload =
      this.flattenForm();


    payload.tnxId =
      this.currentTx.tnxId;


    this.api
      .updateRejectedTransactionSg(
        payload.tnxId,
        payload
      )
      .subscribe({

        next: res => {

          this.snackBar.open(
            `Rejected transaction updated and moved back to Pending (TNX: ${res.tnxId})`,
            'Close',
            {
              duration: 3000
            }
          );


          this.router.navigate(
            [
              '/dashboard/Trade-Services/shipping-guarantee/inquiries-records'
            ],
            {
              queryParams: {
                tab: 'pending'
              }
            }
          );

        },

        error: () => {

          this.snackBar.open(
            'Failed to update rejected transaction',
            'Close',
            {
              duration: 3000
            }
          );

        }

      });

  }


  // =========================================================
  // UPDATE
  // =========================================================

  update(): void {

    if (
      !this.ShippingGuaranteeForm.invalid &&
      this.currentTx?.tnxId
    ) {

      const payload =
        this.flattenForm();

      payload.tnxId =
        this.tnxId;

      console.log(
        'Payload before update:',
        payload
      );

    }

  }


  // =========================================================
  // BACK
  // =========================================================

  back(): void {

    this.router.navigate([
      '/dashboard'
    ]);

  }


  // =========================================================
  // ATTACHMENTS
  // =========================================================

  updateAttachments(
    files: File[]
  ): void {

    const arr =
      this.ShippingGuaranteeForm.get(
        'attachments'
      ) as FormArray;


    arr.clear();


    files.forEach(file => {

      arr.push(
        this.fb.group({

          title:
            file.name.replace(
              /\.[^/.]+$/,
              ''
            ),

          fileName:
            file.name,

          size:
            file.size,

          type:
            file.type,

          file:
            file

        })
      );

    });

  }


  // =========================================================
  // NAVIGATE BACK
  // =========================================================

  private navigateBack(
    tab: string
  ): void {

    this.router.navigate(
      [
        '/dashboard/Trade-Services/shipping-guarantee/approved-inquiry-records'
      ],
      {
        queryParams: {
          tab
        }
      }
    );

  }

}